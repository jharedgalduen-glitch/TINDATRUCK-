TINDATRACK — ENHANCED OFFLINE PWA

Included:
- Product catalog with optional image URL, barcode, supplier, expiry date
- Barcode checkout, cart, amount received and change calculation
- Sale discounts and printable receipt
- Stock-in log, low-stock warnings and expiry alerts
- Sales, expenses, estimated profit, credit/utang and repayments
- Returns/refunds with returned stock added back
- Supplier list
- Seven-day sales chart and estimated cash drawer summary
- English / Filipino / Ilocano navigation labels
- Optional local admin PIN, backup/restore, CSV exports
- PWA shell caching for offline opening after first load

HOW TO RUN AND INSTALL
1. Extract the ZIP into a folder.
2. For normal use, open index.html in a browser. Product data is saved in that browser on this device.
3. To install as a PWA and enable service-worker offline caching, serve this folder from localhost or HTTPS. On Windows, if Python is installed, open Command Prompt in this folder and run:
     python -m http.server 8000
   Then visit http://localhost:8000 in Chrome or Edge, wait for the page to load, and use the browser's Install app option.
4. The app's main features work offline after loading. Camera barcode scanning requires browser camera permission and a secure context (localhost/HTTPS); USB barcode scanners and manually entered barcodes can work without camera access. Camera library download may require internet the first time.
5. Export a JSON backup regularly. Data is local to the browser/device and is not synced to other devices.

SECURITY NOTE
The optional PIN is a basic local lock only, not encryption. Anyone with technical access to the browser profile may be able to access local data. Do not store highly sensitive information in this prototype.
